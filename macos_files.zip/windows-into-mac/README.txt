# Windows-into-mac

This is for anyone who doesn't like the Windows default display and would like to change it.

Getting the Mac Dock: https://www.winstep.net/nexus.asp

Additional skins you might want to add: rainmeter.net

